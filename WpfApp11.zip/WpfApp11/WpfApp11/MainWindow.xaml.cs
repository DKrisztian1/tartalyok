﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Osztályok;
using System.IO;

namespace WpfApp11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Tartaly> tartalyok = new List<Tartaly>();
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Teglatest_checked(object sender, RoutedEventArgs e)
        {
            txtAel.IsEnabled = true;
            txtBel.IsEnabled = true;
            txtCel.IsEnabled = true;
            txtAel.Text = "";
            txtBel.Text = "";
            txtCel.Text = "";
        }

        private void Kocka_checked(object sender, RoutedEventArgs e)
        {
            txtAel.IsEnabled = false;
            txtBel.IsEnabled = false;
            txtCel.IsEnabled = false;
            txtAel.Text = "10";
            txtBel.Text = "10";
            txtCel.Text = "10";
        }

        private void Felvesz(object sender, RoutedEventArgs e)
        {
            Tartaly ujtartaly = new Tartaly(txtNev.Text, Convert.ToInt32(txtAel.Text), Convert.ToInt32(txtBel.Text), Convert.ToInt32(txtCel.Text));
            tartalyok.Add(ujtartaly);
            lbTartalyok.Items.Add(ujtartaly.Info());
        }

        private void Rogzit(object sender, RoutedEventArgs e)
        {
            StreamWriter sw = new StreamWriter("tartalyok.txt", append: true);
            foreach (var item in tartalyok)
            {
                sw.Write($"{item.Nev}; {item.aEl}; {item.bEl}; {item.cEl}; {item.AktLiter} \n");
            }
            sw.Close();
        }

        private void Duplaz(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választottát ki elemet!");
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].DuplazMeretet();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }

        private void Kiurit(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választottát ki elemet!");
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].TeljesLeengedes();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }

        private void Toltes(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nem választottát ki elemet!");
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].Tolt(Convert.ToDouble(txtMennyitTolt.Text));
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }
    }
}
